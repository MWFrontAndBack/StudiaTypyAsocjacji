package Dynamiczne.constuctionCrew;

public class TestConstructCrew {
    public static void main(String[] args) throws Exception {
        ConstructionWorker alex = ConstructionWorker.createPlumber("Alex");
        System.out.println(alex);
        alex.fixWaterFlow();;
        alex.setToPainter();
        alex.paintWalls();
        System.out.println("po robocie");
        System.out.println(alex);
        alex.connectElectricity();
    }
}
