package Dynamiczne.constuctionCrew;

public enum ConstructionCrewWorkerType {
    PAINTER,PLUMBER,ELECTRICIAN,CONSTRUCTION_WORKER
}
