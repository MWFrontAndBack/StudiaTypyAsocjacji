package Dynamiczne.constuctionCrew;

public class ConstructionWorker {
    private String name;
    private ConstructionCrewWorkerType type;

    private Boolean WallsPainted;
    private Boolean AnyWater;
    private Boolean DoesElectrictyWorks;

    public ConstructionWorker(String name) {
        this.name = name;
        this.WallsPainted = false;
        this.AnyWater = false;
        this.DoesElectrictyWorks = false;
    }

    public static ConstructionWorker createElectrician(String name) {
    ConstructionWorker worker = new ConstructionWorker(name);
    worker.type = ConstructionCrewWorkerType.ELECTRICIAN;
    return worker;
    }

    public static ConstructionWorker createPainter(String name) {
        ConstructionWorker worker = new ConstructionWorker(name);
        worker.type = ConstructionCrewWorkerType.PAINTER;
        return worker;
    }

    public static ConstructionWorker createPlumber(String name) {
        ConstructionWorker worker = new ConstructionWorker(name);
        worker.type = ConstructionCrewWorkerType.PLUMBER;
        return worker;
    }

    public void setToPainter() {
        this.type = ConstructionCrewWorkerType.PAINTER;
    }

    public void setToElectrician() {
        this.type = ConstructionCrewWorkerType.ELECTRICIAN;

    }

    public void setToPlumber() {
        this.type = ConstructionCrewWorkerType.PLUMBER;

    }

    public ConstructionCrewWorkerType getCurrentType() {
        return this.type;
    }


    public void paintWalls() throws Exception {
        if (this.type == ConstructionCrewWorkerType.PAINTER) {
            System.out.println("Walls were painted");
            WallsPainted= true;
        } else {
            throw new Exception("You have no qualification");
        }
    }

    public void fixWaterFlow() throws Exception {
        if (this.type == ConstructionCrewWorkerType.PLUMBER) {
            System.out.println("water flow fixed");
            AnyWater = true;
        } else {
            throw new Exception("You have no qualification");
        }
    }

    public void connectElectricity() throws Exception {
        if (this.type == ConstructionCrewWorkerType.ELECTRICIAN) {
            System.out.println("electricity connected");
            DoesElectrictyWorks = true;
        } else {
            throw new Exception("You have no qualification");
        }
    }

    @Override
    public String toString() {
        return "ConstructionWorker{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", WallsPainted=" + WallsPainted +
                ", WaterNeeded=" + AnyWater +
                ", ProblemWithElectricity=" + DoesElectrictyWorks +
                '}';
    }
}
