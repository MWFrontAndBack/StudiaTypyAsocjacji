package Wieloaspektowe;

public enum Platforms {
    PS4,PS5,COMPUTER,XBOX
}
