package Wieloaspektowe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestGames {

    public static void main(String[] args) {
        List<String> enemies = Arrays.asList("enemy1", "enemy2");
        GameType gameType = new ActionGame("Exploration", 20, enemies);

        Game game1 = new Game(
                List.of("Level 1", "Level 2", "Level 3"),
                "Super Mario Bros",
                10,
                Platforms.PS4,
                gameType,
                59.99,
                LocalDate.of(2020, 10, 1),
                9
        );
        List<Integer> puzzles = Arrays.asList(1, 1, 2);
        GameType gameType3 = new PuzzleGame("Treasure Hunt", 15, 560);


        Game game2 = new Game(
                List.of("Chapter 1", "Chapter 2", "Chapter 3", "Chapter 4"),
                "The Last of Us Part II",
                20,
                Platforms.PS5,
                gameType3,
                69.99,
                LocalDate.of(2020, 6, 19),
                8
        );

        List<String> teams = Arrays.asList("Team A", "Team B", "Team C");
        GameType gameType4 = new RacingGame("Soccer", 90, teams);

        Game game3 = new Game(
                List.of("Map 1", "Map 2", "Map 3"),
                "Counter-Strike: Global Offensive",
                500,
                Platforms.COMPUTER,
                gameType4,
                0,
                LocalDate.of(2012, 8, 21),
                10
        );
        List<Game> catalogGames = Arrays.asList(game1, game2, game3);
        GamesCatalog gamesCatalog = new GamesCatalog(catalogGames);
        System.out.println("Metoda szukajaca gre na konkrenna platorme");
        System.out.println(game3.isAvailableOnPlatform(Platforms.COMPUTER));
        System.out.println("Metoda która zwraca gry na platforme w konkretnym rodzaju gry");
        System.out.println(gamesCatalog.findPs4ActionGame());
    }


}
