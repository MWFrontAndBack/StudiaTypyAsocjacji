package Wieloaspektowe;

import java.util.List;

public class PuzzleGame extends GameType {
    private int Scores;

    public PuzzleGame(String title, int length, int scores) {
        super(title, length);
        Scores = scores;
    }

    public int getScores() {
        return Scores;
    }

    public void setScores(int scores) {
        Scores = scores;
    }

    @Override
    public String toString() {
        return "PuzzleGame{" +
                "Scores=" + Scores +
                '}';
    }
}
