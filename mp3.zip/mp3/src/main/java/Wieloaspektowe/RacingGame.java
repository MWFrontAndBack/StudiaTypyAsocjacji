package Wieloaspektowe;

import java.util.List;

public class RacingGame extends GameType {
    private List<String> cars;

    public RacingGame(String title, int length, List<String> cars) {
        super(title, length);
        this.cars = cars;
    }

    public List<String> getCars() {
        return cars;
    }

    public void setCars(List<String> cars) {
        this.cars = cars;
    }

    @Override
    public String toString() {
        return "RacingGame{" +
                "cars=" + cars +
                '}';
    }
}
