package Wieloaspektowe;

import java.util.ArrayList;
import java.util.List;

public class ActionGame extends GameType {
    private List<String> enemies = new ArrayList<>();


    public ActionGame(String title, int length, List<String> enemies) {
        super(title, length);
        this.enemies = enemies;
    }

    public List<String> getEnemies() {
        return enemies;
    }

    public void setEnemies(List<String> enemies) {
        this.enemies = enemies;
    }

    @Override
    public String toString() {
        return "ActionGame{" +
                "enemies=" + enemies +
                '}';
    }
}




