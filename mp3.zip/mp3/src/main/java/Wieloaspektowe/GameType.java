package Wieloaspektowe;

import java.util.ArrayList;
import java.util.List;

public abstract class GameType {
        private Game game;
        private String title;
        private int length;

        public GameType( String title, int length) {
                this.game = game;
                this.title = title;
                this.length = length;
        }

        public Game getGame() {
                return game;
        }

        public void setGame(Game game) {
                this.game = game;
        }

        public String getTitle() {
                return title;
        }

        public void setTitle(String title) {
                this.title = title;
        }

        public int getLength() {
                return length;
        }

        public void setLength(int length) {
                this.length = length;
        }

}
