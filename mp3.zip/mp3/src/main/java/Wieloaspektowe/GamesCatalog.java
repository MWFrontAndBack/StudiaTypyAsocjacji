package Wieloaspektowe;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GamesCatalog {
    private List<Game> gameList = new ArrayList<>();

    public GamesCatalog(List<Game> gameList) {
        this.gameList = gameList;
    }

    public List<Game> findPs4ActionGame() {
        return this.gameList.stream()
                .filter(g -> g.getPlatforms() == Platforms.PS4)
                .filter(g -> {
                    if (g.getGameType() instanceof ActionGame) {
                        return true;
                    }
                    return false;
                })
                .collect(Collectors.toList());
    }
}
