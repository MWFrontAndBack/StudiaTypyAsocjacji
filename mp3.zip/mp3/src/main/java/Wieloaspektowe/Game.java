package Wieloaspektowe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private List<String> levels = new ArrayList<>();
    private String title;
    private int hoursLength;
// enumy
    private  Platforms platforms;

    private GameType gameType;

    private  double price;

    private LocalDate realeaseDate;
    private int rating;

    public Game(List<String> levels, String title, int hoursLength, Platforms platforms, GameType gameType, double price, LocalDate realeaseDate,int rating) {
        this.levels = levels;
        this.title = title;
        this.hoursLength = hoursLength;
        this.platforms = platforms;
        this.gameType = gameType;
        this.price = price;
        this.realeaseDate = realeaseDate;
        this.rating = rating;
    }

    public List<String> getLevels() {
        return levels;
    }

    public void setLevels(List<String> levels) {
        this.levels = levels;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getHoursLength() {
        return hoursLength;
    }

    public void setHoursLength(int hoursLength) {
        this.hoursLength = hoursLength;
    }

    public Platforms getPlatforms() {
        return platforms;
    }

    public void setPlatforms(Platforms platforms) {
        this.platforms = platforms;
    }

    public GameType getGameType() {
        return gameType;
    }

    public void setGameType(GameType gameType) {
        this.gameType = gameType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public LocalDate getRealeaseDate() {
        return realeaseDate;
    }

    public void setRealeaseDate(LocalDate realeaseDate) {
        this.realeaseDate = realeaseDate;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    // moje metody
    public boolean isAvailableOnPlatform(Platforms platform) {
        return platforms==platform;
    }


    @Override
    public String toString() {
        return "Game{" +
                "levels=" + levels +
                ", title='" + title + '\'' +
                ", hoursLength=" + hoursLength +
                ", platforms=" + platforms +
                ", gameType=" + gameType +
                ", price=" + price +
                ", realeaseDate=" + realeaseDate +
                ", rating=" + rating +
                '}';
    }
}

