package overlapping;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private static List<Student> students = new ArrayList<>();
    private String data;
    private List<Double> marks;

    private String Pesel;

    public Student(String data, List<Double> marks, String pesel) {
        students.add(this);
        this.data = data;
        this.marks = marks;
        Pesel = pesel;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public List<Double> getMarks() {
        return marks;
    }

    public void setMarks(List<Double> marks) {
        this.marks = marks;
    }

    public String getPesel() {
        return Pesel;
    }

    public void setPesel(String pesel) {
        Pesel = pesel;
    }

    public static List<Student> getStudents() {
        return students;
    }

    public static void setStudents(List<Student> students) {
        Student.students = students;
    }

    @Override
    public String toString() {
        return "Student{" +
                "data='" + data + '\'' +
                ", marks=" + marks +
                ", Pesel='" + Pesel + '\'' +
                '}';
    }
}
