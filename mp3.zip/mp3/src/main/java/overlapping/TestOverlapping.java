package overlapping;

import java.util.Arrays;
import java.util.List;

public class TestOverlapping {
    public static void main(String[] args) {
        // studenci
        Student s1 = new Student("John Smith", Arrays.asList(3.5, 4.0, 3.0), "1234567890");
        Student s2 = new Student("Jane Doe", Arrays.asList(4.5, 4.0, 5.0), "0987654321");
        Student s3 = new Student("Adam Johnson", Arrays.asList(5.0, 4.0, 4.5), "1357908642");

        UniWorker admin = new UniWorker("Admin", 30, "CS101");
        admin.getUniMemberTypes().add(UniMemberType.ADMINISTRATOR);

        UniWorker teacher = new UniWorker("Teacher", 40, "CS101");
        teacher.getUniMemberTypes().add(UniMemberType.TEACHER);

        UniWorker worker = new UniWorker("Worker", 20, "CS101");

        try {
            List<Student> students = admin.getAcessToStudentsDataBase();
            System.out.println("Admin can access the student database: " + students);

            String groupId = teacher.getNextGrupId();
            System.out.println("Teacher can access group ID: " + groupId);

            groupId = worker.getNextGrupId();

        } catch (Exception e) {
            System.out.println("Worker cannot access group ID.");
        }
    }

}
