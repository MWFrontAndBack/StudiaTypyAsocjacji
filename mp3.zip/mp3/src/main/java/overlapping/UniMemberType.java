package overlapping;

public enum UniMemberType {
    TEACHER,LECTURER,ADMINISTRATOR,UNIWORKER
}
