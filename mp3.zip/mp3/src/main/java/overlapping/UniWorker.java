package overlapping;

import java.util.EnumSet;
import java.util.List;

public class UniWorker {
    private String name;
    private int age;

    private String groupId;
    private EnumSet<UniMemberType> uniMemberTypes = EnumSet.of(UniMemberType.UNIWORKER);

    public UniWorker(String name, int age, String groupId) {
        this.name = name;
        this.age = age;
        this.groupId = groupId;
    }

    public List<Student> getAcessToStudentsDataBase() throws Exception {
        if(uniMemberTypes.contains(UniMemberType.ADMINISTRATOR)){
            return Student.getStudents();
        }else {
            throw  new Exception();
        }
    }

    public String getNextGrupId() throws Exception {
        if(uniMemberTypes.contains(UniMemberType.TEACHER)){
            return groupId;
        }else {
            throw  new Exception();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public EnumSet<UniMemberType> getUniMemberTypes() {
        return uniMemberTypes;
    }

    public void setUniMemberTypes(EnumSet<UniMemberType> uniMemberTypes) {
        this.uniMemberTypes = uniMemberTypes;
    }
}
