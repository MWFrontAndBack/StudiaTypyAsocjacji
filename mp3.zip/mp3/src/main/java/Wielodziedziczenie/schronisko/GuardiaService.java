package Wielodziedziczenie.schronisko;

import java.util.List;

public interface GuardiaService {
     void feedAllAnimals();
     List<String> getCertificatesOrdered();
}
