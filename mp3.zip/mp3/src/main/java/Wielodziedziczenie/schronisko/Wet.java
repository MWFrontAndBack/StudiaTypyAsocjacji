package Wielodziedziczenie.schronisko;

import java.time.LocalDate;
import java.util.List;

public class Wet extends SchelterWorker {
    private List<String> medicalCertificates;

    private AdoptionSpecialist adoptionSpecialist;



//    public Wet(String imie, String nazwisko, String pesel, LocalDate birthday) {
//        super(imie, nazwisko, pesel, birthday);
//    }

    public Wet(String imie, String nazwisko, String pesel, LocalDate birthday, List<String> medicalCertificates, AdoptionSpecialist adoptionSpecialist) {
        super(imie, nazwisko, pesel, birthday);
        this.medicalCertificates = medicalCertificates;
        this.adoptionSpecialist = adoptionSpecialist;
    }

    public AdoptionSpecialist getAdoptionSpecialist() {
        return adoptionSpecialist;
    }

    public void setAdoptionSpecialist(AdoptionSpecialist adoptionSpecialist) {
        this.adoptionSpecialist = adoptionSpecialist;
    }

    public List<String> getMedicalCertificates() {
        return medicalCertificates;
    }

    public void setMedicalCertificates(List<String> medicalCertificates) {
        this.medicalCertificates = medicalCertificates;
    }

    @Override
    public String toString() {
        return "Wet{" +
                "medicalCertificates=" + medicalCertificates +
                ", adoptionSpecialist=" + adoptionSpecialist +
                '}';
    }
}
