package Wielodziedziczenie.schronisko;

public class Animals {
    private String name;
    private boolean beenFeed;

    public Animals(String name) {
        this.name = name;
        this.beenFeed = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isBeenFeed() {
        return beenFeed;
    }

    public void setBeenFeed(boolean beenFeed) {
        this.beenFeed = beenFeed;
    }

    public void feed(){
        this.beenFeed = true;
    }

    @Override
    public String toString() {
        return "Animals{" +
                "name='" + name + '\'' +
                ", beenFeed=" + beenFeed +
                '}';
    }
}
