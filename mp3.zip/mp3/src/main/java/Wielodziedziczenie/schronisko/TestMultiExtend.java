package Wielodziedziczenie.schronisko;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestMultiExtend {
    public static void main(String[] args) {
        List<String> medications = new ArrayList<>(Arrays.asList("Medication 1", "Medication 2"));

        AdoptionSpecialist specialist = new AdoptionSpecialist("John", "Doe", "12345678901", LocalDate.of(1990, 1, 1),null,medications);

        specialist.setEmail("john.doe@example.com");

        List<String> certificates = new ArrayList<>();
        certificates.add("Animal Behavior and Welfare Certification");
        certificates.add("Shelter Management Certification");
        specialist.setCertificates(certificates);

        List<String> animalsToAdopt = new ArrayList<>();
        animalsToAdopt.add("Buddy");
        animalsToAdopt.add("Luna");
        specialist.setListOfAnimalsToAdoption(animalsToAdopt);
        List<Animals> animalsList = new ArrayList<>();

        Animals dog = new Animals("Buddy");
        Animals cat = new Animals("Luna");
        Animals cat2 = new Animals("Coffe");

        animalsList.add(dog);
        animalsList.add(cat);
        animalsList.add(cat2);
        specialist.setAnimals(animalsList);

        System.out.println(specialist);
        System.out.println("Animals before feed");
        specialist.getAnimals().forEach(a -> System.out.println(a.getName() + " was feed? " + a.isBeenFeed()));
        specialist.feedAllAnimals();
        System.out.println("Animals after feed");

        specialist.getAnimals().forEach(a -> System.out.println(a.getName() + " was feed? " + a.isBeenFeed()));

        System.out.println(specialist.getCertificatesOrdered());

        System.out.println(specialist.getWet());


    }

}
