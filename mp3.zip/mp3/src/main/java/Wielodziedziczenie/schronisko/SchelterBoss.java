package Wielodziedziczenie.schronisko;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SchelterBoss extends SchelterWorker {

    private List<SchelterWorker> procownicy = new ArrayList<>();
    private String phoneNumber;


    public SchelterBoss(String imie, String nazwisko, String pesel, LocalDate birthday) {
        super(imie, nazwisko, pesel, birthday);
    }

    public List<SchelterWorker> getProcownicy() {
        return procownicy;
    }

    public void setProcownicy(List<SchelterWorker> procownicy) {
        this.procownicy = procownicy;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
