package Wielodziedziczenie.schronisko;

import java.time.LocalDate;

public class SchelterWorker {
    private String imie;
    private String nazwisko;

    private String pesel;

    private LocalDate birthday;

    public SchelterWorker(String imie, String nazwisko, String pesel, LocalDate birthday) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.pesel = pesel;
        this.birthday = birthday;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "PracownikSchroniska{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", pesel='" + pesel + '\'' +
                ", birthday=" + birthday +
                '}';
    }
}

