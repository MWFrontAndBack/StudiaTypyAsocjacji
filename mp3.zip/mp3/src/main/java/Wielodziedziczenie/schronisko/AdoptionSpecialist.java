package Wielodziedziczenie.schronisko;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdoptionSpecialist extends AnimalGuardian implements GuardiaService {
    List<String> listOfAnimalsToAdoption = new ArrayList<>();

    private Wet wet;

//    public AdoptionSpecialist(String imie, String nazwisko, String pesel, LocalDate birthday) {
//        super(imie, nazwisko, pesel, birthday);
//    }

    public List<String> getListOfAnimalsToAdoption() {
        return listOfAnimalsToAdoption;
    }

    public void setListOfAnimalsToAdoption(List<String> listOfAnimalsToAdoption) {
        this.listOfAnimalsToAdoption = listOfAnimalsToAdoption;
    }



    public AdoptionSpecialist(String imie, String nazwisko, String pesel, LocalDate birthday, List<String> listOfAnimalsToAdoption,List<String> medicametns) {
        super(imie, nazwisko, pesel, birthday);
        this.listOfAnimalsToAdoption = listOfAnimalsToAdoption;
        this.wet = new Wet(null,null,null,null,medicametns,null);
    }
    public Wet getWet() {
        return wet;
    }


    public void setWet(Wet wet) {
        this.wet = wet;
    }

    @Override
    public void feedAllAnimals() {
        super.feedAllAnimals();
    }

    @Override
    public List<String> getCertificatesOrdered() {
        return super.getCertificatesOrdered();
    }
}
