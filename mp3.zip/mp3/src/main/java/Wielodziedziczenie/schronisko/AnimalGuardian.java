package Wielodziedziczenie.schronisko;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AnimalGuardian extends SchelterWorker implements GuardiaService {
    private String email;
    private List<String> certificates;

    private List<Animals> animals = new ArrayList<>();

    public AnimalGuardian(String imie, String nazwisko, String pesel, LocalDate birthday) {
        super(imie, nazwisko, pesel, birthday);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getCertificates() {
        return certificates;
    }

    public void setCertificates(List<String> certificates) {
        this.certificates = certificates;
    }

    public List<Animals> getAnimals() {
        return animals;
    }

    public void setAnimals(List<Animals> animals) {
        this.animals = animals;
    }

    @Override
    public void feedAllAnimals() {
    animals.forEach(Animals::feed);
    }

    @Override
    public List<String> getCertificatesOrdered() {
        return certificates;
    }
}
