package abstrakcyjna;

public enum BreakType {
    disc(10),
    drum(15);
    private final int decreaseSpeedperSecond;

    BreakType(int decreaseSpeed) {
        this.decreaseSpeedperSecond = decreaseSpeed;
    }

    public int getDecreaseSpeedperSecond() {
        return decreaseSpeedperSecond;
    }
}
