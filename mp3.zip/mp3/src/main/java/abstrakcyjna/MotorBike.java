package abstrakcyjna;

import java.awt.*;
import java.time.LocalDate;

public class MotorBike extends Vehicle {
    private final int SPEED_LIMIT = 200;

    private  BreakType breakType;




    public MotorBike(String model, String brand, LocalDate productionDate, Color color, int speed, BreakType breakType) {
        super(model, brand, productionDate, color, speed);
        this.breakType = breakType;
    }

    @Override
    public void accelarate() throws Exception {
    if(getSpeed()<SPEED_LIMIT) {
        super.accelarate();
        System.out.println(getSpeed());
    }else{
        throw  new Exception("Too fast for this Bike");
    }
    }

    @Override
    public void inhibit() {
       this.setSpeed(getSpeed()-breakType.getDecreaseSpeedperSecond());
        System.out.println(getSpeed());
    }

    @Override
    public double calculateSpendfuel(int distanceInKM, double fuelSpend) {
        return super.calculateSpendfuel(distanceInKM, fuelSpend);
    }
}
