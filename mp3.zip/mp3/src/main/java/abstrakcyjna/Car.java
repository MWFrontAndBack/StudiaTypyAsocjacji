package abstrakcyjna;

import java.awt.*;
import java.time.LocalDate;

public class Car extends Vehicle{

    private EngineType engineType;
    private  int doors ;

    public Car(String model, String brand, LocalDate productionDate, Color color, int speed, EngineType engineType) {
        super(model, brand, productionDate, color, speed);
        this.engineType = engineType;
    }

    @Override
    public double calculateSpendfuel(int distanceInKM, double fuelSpend) {
        return distanceInKM * engineType.getLitersPerKm();
    }

    @Override
    public void accelarate() throws Exception {
        super.accelarate();
        System.out.println(getSpeed());
    }

    @Override
    public void inhibit() {
        super.inhibit();
        System.out.println(getSpeed());
    }

    @Override
    public String toString() {
        return super.toString()+ "Car{" +
                "engineType=" + engineType +
                ", doors=" + doors +
                '}';
    }
}
