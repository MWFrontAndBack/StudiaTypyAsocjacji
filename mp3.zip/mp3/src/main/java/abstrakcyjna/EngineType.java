package abstrakcyjna;

public enum EngineType {
    GASOLINE("Gasoline", 0.10),
    DIESEL("Disel", 0.13),
    HYBRID("Hybrid", 0.2),
    ELECTRIC("Electric", 0);

    private final  String name;
    private final double litersPerKm;


    EngineType(String name, double litersPerKm) {
        this.name = name;
        this.litersPerKm = litersPerKm;
    }

    public String getName() {
        return name;
    }

    public double getLitersPerKm() {
        return litersPerKm;
    }
}
