package abstrakcyjna;

import java.awt.*;
import java.time.LocalDate;

public abstract class Vehicle {
    private String model;
    private String brand;
    private LocalDate productionDate;
    private Color color;
    private  int speed;


    public Vehicle(String model, String brand, LocalDate productionDate, Color color, int speed) {
        this.model = model;
        this.brand = brand;
        this.productionDate = productionDate;
        this.color = color;
        this.speed = speed;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public LocalDate getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(LocalDate productionDate) {
        this.productionDate = productionDate;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
    // moje metody

    public void accelarate() throws Exception {
        this.speed +=10;
    }
    public void inhibit(){
        if(this.speed>=0)
        this.speed-=10;
    }
    public double calculateSpendfuel(int distanceInKM,double fuelSpend ){
        return (fuelSpend/distanceInKM)*100;
    }

    @Override
    public String toString() {
        return    "Vehicle{" +
                "model='" + model + '\'' +
                ", brand='" + brand + '\'' +
                ", productionDate=" + productionDate +
                ", color=" + color +
                ", speed=" + speed +
                '}';
    }
}
