package abstrakcyjna;

import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestClassMain {
    public static void main(String[] args) throws Exception {
        System.out.println("samochody");
        Car car1 = new Car("Model X", "Tesla", LocalDate.of(2020, 1, 1), Color.RED, 0, EngineType.ELECTRIC);
        Car car2 = new Car("C-Class", "Mercedes-Benz", LocalDate.of(2021, 5, 20), Color.BLACK, 180, EngineType.GASOLINE);
        Car car3 = new Car("Corolla", "Toyota", LocalDate.of(2018, 6, 15), Color.WHITE, 200, EngineType.GASOLINE);
        Car car4 = new Car("Civic", "Honda", LocalDate.of(2017, 9, 30), Color.BLUE, 300, EngineType.GASOLINE);
        Car car5 = new Car("Mustang", "Ford", LocalDate.of(2022, 2, 28), Color.GREEN, 240, EngineType.GASOLINE);
        Car car6 = new Car("Accord", "Honda", LocalDate.of(2020, 7, 1), Color.BLUE, 150, EngineType.HYBRID);
        Car car7 = new Car("Model Y", "Tesla", LocalDate.of(2021, 10, 10), Color.RED, 200, EngineType.ELECTRIC);
        Car car8 = new Car("Camry", "Toyota", LocalDate.of(2022, 3, 15), Color.BLACK, 500, EngineType.HYBRID);
        List<Car> cars = Arrays.asList(car1,car2,car3,car4,car5,car6,car7,car8);
        cars.forEach(System.out::println);
        System.out.println();
        System.out.println("Motory");
        MotorBike bike1 = new MotorBike("V-Rod", "Harley-Davidson", LocalDate.of(2020, 1, 1), Color.BLACK, 120, BreakType.disc);
        MotorBike bike2 = new MotorBike("Ninja ZX-10R", "Kawasaki", LocalDate.of(2021, 3, 15), Color.GREEN, 140, BreakType.drum);
        MotorBike bike3 = new MotorBike("R 1250 GS", "BMW", LocalDate.of(2022, 2, 10), Color.GRAY, 130, BreakType.disc);
        MotorBike bike4 = new MotorBike("CBR 1000RR-R", "Honda", LocalDate.of(2020, 5, 1), Color.RED, 150, BreakType.drum);
        MotorBike bike5 = new MotorBike("MT-09", "Yamaha", LocalDate.of(2021, 7, 8), Color.BLUE, 125, BreakType.disc);
        MotorBike bike6 = new MotorBike("S 1000 RR", "BMW", LocalDate.of(2022, 4, 20), Color.WHITE, 140, BreakType.drum);
        MotorBike bike8 = new MotorBike("GSX-R1000R", "Suzuki", LocalDate.of(2022, 3, 5), Color.YELLOW, 145, BreakType.drum);
        MotorBike bike7 = new MotorBike("Super Duke R", "KTM", LocalDate.of(2021, 6, 1), Color.ORANGE, 135, BreakType.disc);
        List<MotorBike> bikes = Arrays.asList(bike1,bike2,bike3,bike4,bike5,bike6,bike7,bike8);
bikes.forEach(System.out::println);

// test speed;
        System.out.println("bike");
        System.out.println(bike4.getSpeed());
        bike4.accelarate();
            bike4.inhibit();

            //samochod
        System.out.println("car");
        System.out.println(car1.getSpeed());
        car1.accelarate();
        car1.inhibit();


        double v = car1.calculateSpendfuel(1000, 100);
        System.out.println("bo to tesla " + 0 + "L");

        double v1 = car2.calculateSpendfuel(1000, 100);
        System.out.println("Drugi samochód " + v1 + "L");
    }
}
